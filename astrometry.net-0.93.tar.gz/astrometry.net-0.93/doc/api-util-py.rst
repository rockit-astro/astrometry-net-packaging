Astrometry.net python API reference: astrometry.util
====================================================

.. currentmodule:: astrometry.util

.. _api_util:

WCS handling
------------

.. autoclass:: astrometry.util.util.Tan
   :members:

.. autoclass:: astrometry.util.util.tan_t
   :members:

